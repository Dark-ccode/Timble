<template>
<div class="cont">
<Header class="dhead resnone"/>
<ResHeader class="rhead"/>
  <Navcont class="desknone"/>

<div class="about">
<div class="row">

<div class="col-md-8">
<div class="h">Top Reviews</div>

<div class="testcard" data-aos="slide-up">
<div class="headsec">
<div class="n ib"> Ogbowo Bright <div class="time ib">  may 4 </div></div>
</div>
<div class="msg">
"Wow such a nice app, we did'nt have this type during our time, the apps functionality is superb!"
<br>
<div class="revstarcont">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
</div>
</div>
</div>

<div class="testcard" data-aos="slide-up">
<div class="headsec">
<div class="n ib"> Emmanuel Orji<div class="time ib">  may 18 </div></div>
</div>
<div class="msg">
"A very Efficient and effective way to claculate your result,i used it and the poutput i got was accurate, Kudos to the developers."
<br>
<div class="revstarcont ib">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
</div>
</div>
</div>


<div class="testcard" data-aos="slide-up">
<div class="headsec">
<div class="n ib"> James Uba <div class="time ib">  July 12 </div></div>
</div>
<div class="msg">
"This is a great tool for higher institution students, with this i dont think there will be any result miscalculation."
<br>
<div class="revstarcont">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">
<img src="../assets/starg.png" class="rstar_img">

</div>
</div>
</div>

<div class="more">more</div>

</div>
<div class="col-md-4" data-aos="zoom-in">
<div class="h rh" data-aos="zoom-in">Review App</div>

<input type="text" placeholder="Name" class="in" v-model="name">
<textarea  placeholder="Write something" v-model="msg"></textarea>

<div class="sr">Star Rating</div>
<div class="starcont">
<div class="tstarcont">
  <img src="../assets/starg.png" alt="one star" class="star_img s1g">
</div>
 
 <div class="tstarcont">
  <img src="../assets/star1.png"  class="star_img s2b">
  <img src="../assets/starg.png"  class="star_img s2g none">
</div>

 <div class="tstarcont">
  <img src="../assets/star1.png" class="star_img s3b">
  <img src="../assets/starg.png" class="star_img s3g none">
</div>

<div class="tstarcont">
  <img src="../assets/star1.png" class="star_img s4b">
  <img src="../assets/starg.png" class="star_img s4g none">
</div>

<div class="tstarcont">
  <img src="../assets/star1.png" class="star_img s5b">
  <img src="../assets/starg.png" class="star_img s5g none">
</div>

 <!-- <img src="../assets/star1.png" alt="four stars" class="star_img" id="s4">
  <img src="../assets/star1.png" alt="five stars" class="star_img" id="s4">
-->
</div>

<div class="submit" v-on:click="submit()">Submit</div>
<br>

<div class="thanks card none">
  <img src="../assets/x.png" class="cancel cancel1">
  Hi {{name}}, <br>
  Timble has recieved your review <!--thanks for giving {{star}} star(s)-->, this will go a long way inimproving the app and motivate us.
  Thanks for reveiwing this app.
</div>

<div class="error card none">
  <img src="../assets/x.png" class="cancel cancel2">
 Form cannot be submitted empty, please fill in the inputs.
</div>


</div>


</div>




</div>

<div class="forres desknone">
</div>

  <Footer class="resnone"/>

<!--<Footer />-->
</div>
</template>

<script>
import Header from './plugins/header.vue'
import ResHeader from './plugins/resheader.vue'
import Navcont from './plugins/nav.vue'
import Footer from './plugins/Footer.vue'


import AOS from 'aos'
import 'aos/dist/aos.css'

import $ from 'jquery'
export default {
name: 'Review',
data() { 
  return {name:"",msg:'',star:1}
},
components: {
Header,
ResHeader,
Navcont,
Footer
},
methods:{ 
submit: function(){
if(this.name=="" && this.msg==""){
$(".error").show(600)
$(".thanks").hide()

}

else if(this.name!="" && this.msg!=""){
//$(".error2").text('please append yout name to the review')
$(".thanks").show(600).delay(1000)
$(".error").hide()

}

}
},

mounted(){
AOS.init()

$(".cancel1").click(function(){
$(".thanks").hide(600)
})

$(".cancel2").click(function(){
$(".error").hide(600)
})

var x = 0;

//2
$(".s2b").click(function(){
$(".s2b").hide()
$(".s2g").show()
x = 2
this.star = x
console.log(this.star)
})

$(".s2g").click(function(){
$(".s2g").hide()
$(".s3g").hide()
$(".s4g").hide()
$(".s5g").hide()

$(".s2b").show()
$(".s3b").show()
$(".s4b").show()
$(".s5b").show()
})

//3
$(".s3b").click(function(){
$(".s2b").hide()
$(".s3b").hide()

$(".s3g").show()
$(".s2g").show()

x = 3
this.star = x

})

$(".s3g").click(function(){
$(".s2g").hide()
$(".s3g").hide()
$(".s4g").hide()
$(".s5g").hide()

$(".s2b").show()
$(".s3b").show()
$(".s4b").show()
$(".s5b").show()
})

//4
$(".s4b").click(function(){
$(".s2b").hide()
$(".s3b").hide()
$(".s4b").hide()

$(".s3g").show()
$(".s2g").show()
$(".s4g").show()

x = 4
this.star = x

})

$(".s4g").click(function(){
$(".s2g").hide()
$(".s3g").hide()
$(".s4g").hide()
$(".s5g").hide()

$(".s2b").show()
$(".s3b").show()
$(".s4b").show()
$(".s5b").show()
})

//5
$(".s5b").click(function(){
$(".s2b").hide()
$(".s3b").hide()
$(".s4b").hide()
$(".s5b").hide()

$(".s3g").show()
$(".s2g").show()
$(".s4g").show()
$(".s5g").show()
x = 5
this.star = x

})

$(".s5g").click(function(){
$(".s2g").hide()
$(".s3g").hide()
$(".s4g").hide()
$(".s5g").hide()

$(".s2b").show()
$(".s3b").show()
$(".s4b").show()
$(".s5b").show()
})

}}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
input{outline: none;}

.desknone{display: none;}
.about{padding: 70px;margin-top: 20px;color: black;font-size: 17px;}
.h{font-size: 24px;margin-bottom: 20px;margin-top: 40px;color: rgb(37, 37, 204);}
.rh{font-size: 20px;}
.testcard{margin-top: 10px;width: 80%;margin-left: 0%;height: auto;padding: 5px;border-radius: 2px;
background-color:   white;font-size: 16px;background-clip:border-box;border-radius:15px;text-align: left;margin-bottom: 30px;
box-shadow: 2px 2px 2px 2px rgb(236, 236, 236);padding-bottom: 25px;}
.ib{display: inline-block;}
.n{font-size: 17px;margin-bottom: 10px; color: rgb(37, 37, 204);margin-top: 5px;font-weight: bold;}
.time{font-size: 12px;font-weight: lighter;margin-top: -2px;color: rgb(37, 37, 204);margin-left: 10px;}
.msg{margin-top:0px;padding: 2px;font-size: 14px;}
.in{width: 100%;height: 40px;border: 3px solid rgb(37, 37, 204);margin-bottom: 30px;border-radius: 8px;}
textarea{width: 100%;height: 105px;border: 3px solid rgb(37, 37, 204);margin-bottom: 10px;border-radius: 8px;}
.sr{color:rgb(37, 37, 204);}
.submit{width: 40%;height: 40px;color: white;background-color:rgb(37, 37, 204) ;padding: 5px;font-size: 15px;
border-radius: 8px;float: right;text-align: center;text-transform: uppercase;padding-top: 9px;font-weight: bold;}

.starcont{background-color: rgb(236, 236, 236);margin-bottom: 30px;height: 60px;display: flex;flex-direction: row;border-radius: 15px;
padding-top: 12px;padding-left: 60px;}
.star_img{width: 30px;height: 30px;margin-left: 10px;margin-right: 10px;padding: 5px;}

.revstarcont{margin-bottom: 20px;height: auto;display: flex;flex-direction: row;float: right;margin-top: -10px;margin-right: 10px;}
.rstar_img{width: 20px;height: 20px;margin-left: 10px;margin-right: 10px;padding: 3px;}

.thanks,.error{padding:20px;font-size: 15px;margin-top: 50px;}
.cancel{width: 30px;height: 30px;margin-right: -10px;padding: 5px;float: right;margin-top: -15px;margin-bottom: 10px;}
.more{text-align: right;color: rgb(37, 37, 204);width: 80%;font-size: 13px;font-weight: bold;}
@media screen and (max-width:480px){
.about{padding: 20px;margin-top: 10px;color: black;font-size: 15px;text-align: justify;}
.h{font-size: 21px;margin-bottom: 20px;margin-top: 40px;color: rgb(37, 37, 204);}
.testcard{width: 100%;}
.starcont{height: 50px;padding-top: 12px;padding-left: 50px;}
.star_img{width: 20px;height: 20px;margin-left: 7px;margin-right: 7px;padding: 0px;}

.revstarcont{margin-bottom: 20px;height: auto;display: flex;flex-direction: row;float: right;margin-top: 5px;margin-right: 10px;}
.rstar_img{width: 20px;height: 20px;margin-left: 5px;margin-right: 5px;padding: 5px;}
.cancel{width: 25px;height: 25px;padding: 5px;float: right;}
.more{width: 100%;font-size: 13px;}

}
</style>
