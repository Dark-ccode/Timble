<template>
<div class="cont">
<Header class="dhead resnone"/>
<ResHeader class="rhead"/>
  <Navcont class="desknone"/>

<div class="about t">

<div class="row1 r" data-aos="slide-up">

<div class="abouthead" data-aos="zoom-in">About Timble </div>
Simple and Beautiful way to calculate your GPA <b>Real time Calculation</b>,Timble is a comprehensive highly customizable app that is used to calculate:<br>
<ul>
<li> The Semester GPA</li>
<li> Cumulative GPA</li>
</ul>
You can customize your grading system by editing grades and their corresponding points with attractive interface.<br>
TImble has a Real time calculation with FULL material design and high speed.
Basically SGPA calculates your semester wise grade through your subject credits and secured marks.
CGPA calculates  year wise grade through your secured SGPA in semesters and total credit points of subjects in semester.
<br>
It fully follows the general higher institutions guidelines to calculate your SGPA and CGPA. Other people can check with their actual secured grade in this calculator if its same they can also use this calculator.

Sometime Students secured some low grade in paper and apply for rechecking, so through this calculator they can also predict their SGPA by their expectations grades.

We put an additional feature to help you to get your actual modified mark sheet in .pdf format.

</div>

<div class="row3 r rr" data-aos="slide-up">
<div class="abouthead ah">What's new</div>
<ul>
<li> Decimal field fixes in SGPA and CGPA input fields</li>
<li> Alignment fixes in SGPA and CGPA</li>
<li> Calculated result can be downloaded as pdf</li>
</ul>
</div>


<div class="row3">
<div class="abouthead ah">Developed by</div>
<div class="devname">
 Ukonu George Chukwuebuka 
</div>
</div>


</div>

<div class="forres desknone">
</div>


  <Footer class="resnone"/>


</div>
</template>

<script>
import Header from './plugins/header.vue'
import ResHeader from './plugins/resheader.vue'
import Navcont from './plugins/nav.vue'
import Footer from './plugins/Footer.vue'
import AOS from 'aos'
import 'aos/dist/aos.css'
export default {
name: 'AboutPage',
components: {
Header,
ResHeader,
Navcont,
Footer
},
mounted() {AOS.init()},

}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.desknone{display: none;}
.rhead{display: none;}
.about{padding: 70px;margin-top: 20px;color: black;font-size: 17px;}
.abouthead{font-size: 24px;margin-bottom: 20px;margin-top: 20px;color: rgb(37, 37, 204);}
.sitename{color: rgb(37, 37, 204);}
.r{margin-top: 40px;}
.rr{text-align: left;}
.ah{color: rgb(37, 37, 204);}

.devname{font-size: 21px;font-weight: bold;text-align: left;margin-top: -10px;}

@media screen and (max-width:480px){
.about{padding: 10px;margin-top: 10px;color: black;font-size: 15px;text-align: left;}
.abouthead{font-size: 21px;margin-bottom: 20px;margin-top: 20px;color: rgb(37, 37, 204);}
.forres{display: block;}

.resnone{display: none;}
.rhead{display:block;}
.devname{font-size: 17px;font-weight: bold;text-align: left;margin-top: -10px;}

}
</style>
