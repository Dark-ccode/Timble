<template>
<div class="above"><br><br>
<div id="slider" class="">

<div id="slide1">
<div class="row slide row1" data-aos="zoom-in">
<div class="col-md-6 writeup coll">
  <br><br>
  <div class="comentry">Simple and fun way to calulate your results. </div>
  <div class="say">A comprehensively highly customizable app that calculates: Semester GPA, Cummulative GPA.
</div>
  <a href="http://www.app.echelontech.com.ng/app/index.html" class="action_btn">Try it</a>
<a href="Timble.apk" class="action_btn ab2">Download Now</a>

</div>
<div class="col-md-6 imgcont">
  <img src="../../assets/s1.png" alt="slide1" class="slide_img">
</div>
</div>
</div>

<!---------------------------------------------------------------------------------->
<div id="slide2" class="none">
<div class="row slide row2">
<div class="col-md-6 writeup">
  <div class="comentry">An Easy Tool to Calculate stuffs related to GPA/CGPA</div>
  <div class="say">Other people can check with their actual secured grade in this calculator if its same they can also use this calculator.</div>
  <br><br>
 
  <router-link to="/Login" class="action_btn">Try it</router-link>
<router-link to="/Signup" class="action_btn ab2">Download Now</router-link>


</div>
<div class="col-md-6 imgcont">
  <img src="../../assets/s2.png" alt="slide1" class="slide_img">
</div>
</div>
</div>
</div>
</div>

</template>


<script>
import AOS from 'aos'
import 'aos/dist/aos.css'
//import $ from "jquery"
export default {
  name: 'Slide',
  components: {
  //Footer,
  },
mounted() {
  AOS.init()

}
}

/*

//window.addEventListener('load',start)
var K = 0;
var animation = () => {
// get the two slides 
//var s1 = document.getElementById("slide1")
//var s2 = document.getElementById("slide2")
K++
if(K==1){
  $("#slide1").hide()
  $("#slide2").show()
}

else if(K==2){
  $("#slide1").show()
  $("#slide2").hide()
  K=0;
}
}

//var start = setInterval(animation,6000)

*/

</script>

<style scoped>

.none{display: none;}
#slider{padding: 0px 50px 80px 50px;/*background-image: url("../../assets/bg1.jpg");*/background-size: 100%;margin-top: 100px; padding-bottom: 0px;}
.comentry{font-size: 45px; color: rgb(37, 37, 204);margin-bottom: 15px;margin-top: 60px;font-weight:bolder;width: 100%;}
.say{font-size: 28px;color: black;word-spacing: -5px;}
.action_btn{width: 100px;padding: 7px;height: 32px;margin-left: 0px;margin-right: 20px;display: inline-block;border: 3px solid rgb(37, 37, 204);
background-color: transparent;color: black; text-align: center;font-size: 14px;border-radius: 5px;text-decoration: none;height: 40px;display: none;font-weight: bold;}
.ab2{width: 150px;margin-right: 0px;display: block;width: 200px;height: 50px;margin-top: 40px;padding-top: 10px;font-size: 18px;}
.slide_img{width: 100%;height: 530px;}
.imgcont{padding-right: 20px;text-align: center;}
.writeup{padding-left: 40px;}
.coll{text-align: justify;word-spacing: -1px;}


@media screen and (max-width:480px){
#slider{padding: 0px 00px 00px 0px;margin-top: 20px; }
.comentry{font-size: 27px;margin-bottom: 15px;}
.say{font-size: 18px;word-spacing: 0px;text-align: left;}
.slide_img{width: 100%;height: 250px;margin-top: 0px;position: absolute;top: 20px;left: 0%;}
.writeup{padding: 20px;padding-left: 20px;margin-top: 160px;padding-bottom: 0px;}
.action_btn,.ab2{width: 100px;padding: 7px;height: 32px;margin-left: 0px;margin-right: 20px;display: inline-block;border: 3px solid rgb(37, 37, 204);
background-color: transparent;color: black; text-align: center;font-size: 14px;border-radius: 5px;text-decoration: none;height: 40px;display: none;font-weight: bold;}
.ab2{width: 150px;}
.action_btn{ display: inline-block;margin-top: 20px;}

/*
.none{display: none;}
#slider{padding: 0px 50px 80px 50px;background-image: url("../../assets/bg1.jpg");background-size: 100%;margin-top: 60px; }
.comentry{font-size: 50px; color: rgb(37, 37, 204);margin-bottom: 15px;margin-top: 20px;font-weight:bolder}
.say{font-size: 27px;color: white;}
.action_btn{width: 100px;padding: 7px;height: 32px;margin-left: 0px;margin-right: 20px;display: inline-block;border: 3px solid rgb(37, 37, 204);
background-color: transparent;color: white; text-align: center;font-size: 14px;border-radius: 5px;text-decoration: none;height: 40px;}
.slide_img{width: 100%;height: 400px;}
.imgcont{padding-right: 50px;text-align: center;}

@media screen and (max-width:480px){
#slider{padding: 0px 00px 00px 0px;margin-top: 20px; }
.comentry{font-size: 27px;margin-bottom: 15px;margin-top: 20px;}
.say{font-size: 22px;}
.slide_img{width: 100%;height: 220px;margin-top: 30px;}
.writeup{padding: 20px;padding-left: 30px;}*/
}
</style>