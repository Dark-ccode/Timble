<template>
<div class="head">
<div class="row">
<div class="col-md-3">
<router-link to="/">   <span class="site_name"> TIMBLE </span> </router-link>
</div>


<div class="col-md-6">
  <div class="navcont">
    
<router-link to="/" class="navs">Home</router-link>
<router-link to="/about" class="navs">About app</router-link>
<router-link to="/Review" class="navs">Review</router-link>
<!--<router-link to="/Contact" class="navs ">Developer's contact</router-link>-->

  </div>
</div>
<div class="col-md-1"></div>
<div class="col-md-2">
<a href="Timble.apk"  class="action_btn signup">Download Now</a>
</div>

</div>
</div>
</template>

<script>
import $ from "jquery"

export default {
  name: 'Header',
methods:{ 

},

}

window.addEventListener('scroll', function(){
console.log(window.scrollY)
if (window.scrollY!=0) {
$("#head").css("background-color","rgba(0, 0, 0, 0.788)").css("color","white")
}

if (window.scrollY==0) {
$("#head").css("background-color","transparent").css("color","steelblue")
//$(".r4,.card,.contributors").hide()
}
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only  #101112;  #343c66-->
<style>
.navs{margin-left: 14px;margin-right: 14px;color:#a8a899;font-size: 18px;text-decoration: none;margin-top: 10px;}
.navs:hover{color: rgb(37, 37, 204);font-weight: bold;}
.head{padding:30px 40px 0px 40px;background-color: white;position: fixed;height: 100px;width: 100%;z-index: 2;top: 0px;
box-shadow: 2px 2px 2px 2px rgb(236, 236, 236);} /* top right bottom left     box-shadow:0px 1px 0px 0px rgba(255, 255, 255, 0.801); */

.action_btn,.a{width: 150px;padding: 7px;height: 32px;margin-left: 0px;margin-right: 20px;display: inline-block;border: 3px solid rgb(37, 37, 204);
background-color: transparent;color: black; text-align: center;font-size: 14px;border-radius: 5px;text-decoration: none;height: 40px;font-weight: bold;}


a{text-decoration: none;}
.router-link-active,.a{color: rgb(37, 37, 204);font-weight: bold;}
.desknone{display: none;}
.none{display: none;}
.site_name{font-size: 28px;margin-top: -4px;display: inline-block;margin-left: 5px;font-weight: bolder;color:rgb(37, 37, 204) ;}

@media screen and (max-width:480px){
}
</style>
