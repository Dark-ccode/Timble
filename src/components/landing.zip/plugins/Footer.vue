<template>

<div id="footer" class="">
<div class="row frow3">
<div class="col-md-12 copy">Copyright ©2022 Timble. All Rights Reserved.<br> <div class="powered resnone">Powered by Echelon Tech LLC</div>  </div>
</div>
</div>
</template>


<script>

export default {
name: 'Footer',
components: {
//Footer,
}
}
</script>

<style>
#footer{background-color: white;padding: 5px;padding-bottom: 0px;color: rgb(37, 37, 204);margin-top: 50px;margin-bottom: -40px;}
.copy{text-align: center;color: #a8a899;}
.powered{color: rgb(37, 37, 204);font-weight: bold;box-shadow: 2px 2px 0px 0px rgb(236, 236, 236);}
@media screen and (max-width:480px){
.copy{font-size: 12px;}

}
</style>