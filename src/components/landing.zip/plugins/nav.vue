<template>

<div class="resmenu">


<div class="mmenucont">
<!--<router-link to="/" class="res_navs">  Home</router-link>-->
<router-link to="/" class="res_navs">Home</router-link>
<router-link to="/about" class="res_navs">About app</router-link>
<router-link to="/Review" class="res_navs">Review app</router-link>
<!--<router-link to="/Contact" class="res_navs">Developers Contact</router-link>-->
 </div>
<a href="Timble.apk"  class="action_btn rm"> <img src="../../assets/a2.png" alt="" class="rmimg none"> Download App</a>


<div class="pcont">
<div class="powered1">Powered By</div>
<div class="powered">Echelon Tech LLC</div>
</div>

</div>
</template>


<script>
import $ from "jquery"

export default {
  name: 'Resmenu',
  components: {
  },
  mounted(){
    $(".cn").click(function(){
$(".calc_submenu").toggle(500)
$(".cn").css("color","rgb(37, 37, 204)")
$(".router-link-active").css("color","black")
})
  }
}
</script>

<style scoped>


@media screen and (max-width:480px){
.none{display: none;}
.res_navs{margin-top: 20px;margin-bottom: 20px;padding-left: 25px;font-size: 21px;
text-decoration: none;color: rgb(36, 36, 36);display: block;}
.resmenu{padding-bottom: 20px;;width: 90%;display: none;box-shadow: 1px 1px 1px 1px rgb(236, 236, 236);z-index: 999;
padding: 20px;color: rgb(36, 36, 36);background-color:/* #000000e7*/ #ffffffe7;position: fixed;left:0%;top: 60px;height: 100%;backdrop-filter: blur(2px)}
.mmenucont{margin-top: 40px;}
.rm{margin-top: 50px;font-size: 14px;width: 80%;margin-left: 10%;margin-bottom: 20px;padding: 5px;text-align: center;padding-top: 8px;
background-color: transparent;border-radius: 15px;color:rgb(37, 37, 204);
display: block;border: 2px solid rgb(37, 37, 204);}
.rmimg{height: 17px;width: 17px;margin-left: 5px;}
.router-link-active{color:rgb(37, 37, 204);font-weight: bold;}
a,a:visited{text-decoration: none;}
.calc_submenu{padding-left: 20px;}
.subnavs{font-size: 16px;margin-top: 10px;margin-bottom: 10px;}
.cn{margin-bottom: 5px;}

.powered{color:rgb(37, 37, 204);font-size: 16px;}
.powered1{color:grey;font-size: 14px;}
.pcont{position: fixed;bottom: 10px;width: 100%;text-align: center;font-weight: bolder;margin-left: -10%;}

}

</style>