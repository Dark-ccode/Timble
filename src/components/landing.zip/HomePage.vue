<template>
<div class="cont">
<Header class="dhead resnone"/>
<ResHeader class="desknone head"/>
<slide />

<div class="home">

</div>
<Navcont class="desknone"/>
  <Footer />

</div>

</template>

<script>
//import $ from "jquery"

import Header from './plugins/header.vue'
import ResHeader from './plugins/resheader.vue'
import Slide from './plugins/slide.vue'
import Navcont from './plugins/nav.vue'
import Footer from './plugins/Footer.vue'

/*import AOS from 'aos'
import 'aos/dist/aos.css'*/

export default {
name: 'HomePage',
components: {
Slide,
Header,
ResHeader,
Navcont,
Footer
},
//mounted() {AOS.init()}, data-aos="slide-up"
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only #2c3e50-->
<style scoped>
body{overflow-x: hidden;}
.desknone{display: none;}

@media screen and (max-width:480px){

.head{display: inline-block;}
.resnone{display: none;}
}
</style>
