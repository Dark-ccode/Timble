import Vue from 'vue'
import App from './App.vue'
import Router from 'vue-router'
//import router from 'vue-router/dist/vue-router.js'
import 'bootstrap/dist/css/bootstrap.min.css'
import VueRouter from 'vue-router'
import 'animate.css'
Vue.use(Router)
Vue.config.productionTip = false

import Home from './components/HomePage.vue'
import About from './components/AboutPage.vue'
import Review from './components/Review.vue'


const routes =[
{path:'/',component:Home},
{path:'/about',component:About},
{path:'/Review',component:Review},

]

const router = new VueRouter({routes})





new Vue({
router,
render: h => h(App),
}).$mount('#app')
