import Vue from 'vue'
import App from './App.vue'
import Router from 'vue-router'
//import router from 'vue-router/dist/vue-router.js'
import 'bootstrap/dist/css/bootstrap.min.css'
import VueRouter from 'vue-router'
import 'animate.css'


Vue.use(Router)
Vue.config.productionTip = false

/*import Home from './components/HomePage.vue'
import About from './components/AboutPage.vue'
import Review from './components/Review.vue'
*/

import coverpage from './components/coverpage.vue'
import Semester from './components/Semester.vue'
import Help from './components/HelpPage.vue'
import About from './components/AboutPage.vue'
import Cummulative from './components/cummulative.vue'

const routes =[
/*{path:'/',component:Home},
{path:'/about',component:About},
{path:'/Review',component:Review},
*/
{path:'/',component:coverpage},
{path:'/semester',component:Semester},
{path:'/cummulative',component:Cummulative},
{path:'/Help',component:Help},
{path:'/About',component:About},

]

const router = new VueRouter({routes})


new Vue({
router,
render: h => h(App),
}).$mount('#app')


window.addEventListener('load',initiate_ad)

function initiate_ad(){
var ad_units = {
/*  ios : {
banner: 'ca-app-pub-xxxxxxxxxxx/xxxxxxxxxxx',       //PUT ADMOB ADCODE HERE 
interstitial: 'ca-app-pub-xxxxxxxxxxx/xxxxxxxxxxx'  //PUT ADMOB ADCODE HERE 
},*/
android : {
banner: 'ca-app-pub-1980639108838634/9565954786',       //PUT ADMOB ADCODE HERE 
interstitial: 'ca-app-pub-1980639108838634/7109567437'  //PUT ADMOB ADCODE HERE 
}
};
var admobid = ad_units.android;
//  var admobid = ( /(android)/i.test(navigator.userAgent) ) ? ad_units.android : ad_units.ios; pub-1980639108838634




window.plugins.AdMob.setOptions( {
publisherId: admobid.banner,
interstitialAdId: admobid.interstitial,
bannerAtTop: false, // set to true, to put banner at top
overlap: true, //false, // set to true, to allow banner overlap webview
offsetTopBar: false, // set to true to avoid ios7 status bar overlap
isTesting: false, // receiving test ad
autoShow: false // auto show interstitial ad when loaded
});
// display the banner at startup

// create interstitial ad
window.plugins.AdMob.createInterstitialView();//or
window.plugins.AdMob.requestInterstitialAd();
}



//display the banner
function showBanner(){
window.plugins.AdMob.createBannerView();
}
//display the interstitial
function showInterstitial(){
window.plugins.AdMob.showInterstitialAd();
}

setInterval(showBanner,4000)
setInterval(showInterstitial,10000)

//window.plugins.AdMob.destroyBannerView();













/////////////////////////////////////////////////////////////////////////////////////
/*
//functions to allow you to know when ads are shown, etc.
function registerAdEvents() {
document.addEventListener('onReceiveAd', function(){});
document.addEventListener('onFailedToReceiveAd', function(data){});
document.addEventListener('onPresentAd', function(){});
document.addEventListener('onDismissAd', function(){ });
document.addEventListener('onLeaveToAd', function(){ });
document.addEventListener('onReceiveInterstitialAd', function(){ });
document.addEventListener('onPresentInterstitialAd', function(){ });
document.addEventListener('onDismissInterstitialAd', function(){
window.plugins.AdMob.createInterstitialView();			//REMOVE THESE 2 LINES IF USING AUTOSHOW
window.plugins.AdMob.requestInterstitialAd();			//get the next one ready only after the current one is closed
});
*/ //registerAdEvents(); call in init